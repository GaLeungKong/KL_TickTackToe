using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

namespace TicTacToe
{
    public class GameUI : MonoBehaviour
    {
        [SerializeField] private GridCell[] gridCells;
        [SerializeField] private TMP_Text statusText;
        [SerializeField] private Button restartButton;
        [SerializeField] private TMP_Dropdown difficultyDropdown;

        private GameController gameController;

        private void Start()
        {
            gameController = GetComponent<GameController>();
            InitializeUI();
        }

        private void InitializeUI()
        {
            for (int i = 0; i < gridCells.Length; i++)
            {
                int index = i;
                gridCells[i].Button.onClick.AddListener(() => OnCellClicked(index));
            }

            // 初始化重启按钮
            restartButton.GetComponentInChildren<TMP_Text>().text = GameText.RESTART_BUTTON;
            restartButton.onClick.AddListener(gameController.RestartGame);

            // 初始化难度选择下拉框
            if (difficultyDropdown != null)
            {
                difficultyDropdown.ClearOptions();
                difficultyDropdown.AddOptions(new List<string> { "Easy", "Medium", "Hard" });
                difficultyDropdown.onValueChanged.AddListener(OnDifficultyChanged);
            }
        }

        public void UpdateStatus(string message)
        {
            statusText.text = message;
        }

        public void UpdateCell(int index, CellState state)
        {
            gridCells[index].SetState(state);
        }

        private void OnCellClicked(int index)
        {
            gameController.OnPlayerMove(index);
        }

        private void OnDifficultyChanged(int value)
        {
            AIDifficulty difficulty = (AIDifficulty)value;
            gameController.SetAIDifficulty(difficulty);
            gameController.RestartGame();
        }
    }
} 