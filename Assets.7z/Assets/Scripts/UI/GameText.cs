namespace TicTacToe
{
    public static class GameText
    {
        // Game status messages
        public const string YOUR_TURN = "Your Turn";
        public const string AI_THINKING = "AI Thinking...";
        public const string YOU_WIN = "You Win!";
        public const string AI_WIN = "AI Wins!";
        public const string DRAW = "Draw!";
        
        // UI text
        public const string RESTART_BUTTON = "Restart";
        public const string PLAYER_SYMBOL = "X";
        public const string AI_SYMBOL = "O";
        public const string EMPTY_CELL = "";

        // Text style constants
        public const float CELL_FONT_SIZE = 36f;
        public const float STATUS_FONT_SIZE = 24f;
        public const float BUTTON_FONT_SIZE = 18f;
    }
} 