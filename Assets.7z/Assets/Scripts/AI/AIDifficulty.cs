namespace TicTacToe
{
    public enum AIDifficulty    // AI难度设置
    {
        Easy,       // 随机下棋
        Medium,     // 部分最优解
        Hard        // 完美策略
    }  // end of enum
} 