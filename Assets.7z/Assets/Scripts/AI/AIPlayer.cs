using System.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;

namespace TicTacToe
{
    public class AIPlayer
    {
        private readonly Board board;
        private AIDifficulty difficulty;
        
        public AIPlayer(Board board, AIDifficulty difficulty = AIDifficulty.Hard)
        {
            this.board = board;
            this.difficulty = difficulty;
        }

        public void SetDifficulty(AIDifficulty newDifficulty)
        {
            difficulty = newDifficulty;
        }

        public async Task<int> GetNextMoveAsync()
        {
            await Task.Delay(500); // 模拟思考时间

            return difficulty switch
            {
                AIDifficulty.Easy => GetRandomMove(),
                AIDifficulty.Medium => GetMediumMove(),
                _ => GetBestMove() // Hard难度
            };
        }

        private int GetRandomMove()
        {
            // 获取所有空位置
            List<int> availableMoves = new List<int>();
            for (int i = 0; i < 9; i++)
            {
                if (board.GetCell(i) == CellState.Empty)
                {
                    availableMoves.Add(i);
                }
            }

            // 随机选择一个位置
            if (availableMoves.Count > 0)
            {
                int randomIndex = Random.Range(0, availableMoves.Count);
                return availableMoves[randomIndex];
            }
            return -1;
        }

        private int GetMediumMove()
        {
            // 70%概率使用最优解，30%概率随机下棋
            if (Random.value < 0.7f)
            {
                return GetBestMove();
            }
            return GetRandomMove();
        }

        private int GetBestMove()
        {
            int bestScore = int.MinValue;
            int bestMove = 0;
            CellState[] tempBoard = new CellState[9];

            // 复制当前棋盘状态
            for (int i = 0; i < 9; i++)
            {
                tempBoard[i] = board.GetCell(i);
            }

            // 在临时棋盘上模拟移动
            for (int i = 0; i < 9; i++)
            {
                if (tempBoard[i] == CellState.Empty)
                {
                    tempBoard[i] = CellState.O;
                    int score = Minimax(tempBoard, 0, false);
                    tempBoard[i] = CellState.Empty;

                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestMove = i;
                    }
                }
            }

            return bestMove;
        }

        private int Minimax(CellState[] tempBoard, int depth, bool isMaximizing)
        {
            if (CheckWin(tempBoard, CellState.O)) return 10 - depth;
            if (CheckWin(tempBoard, CellState.X)) return depth - 10;
            if (IsBoardFull(tempBoard)) return 0;

            if (isMaximizing)
            {
                int bestScore = int.MinValue;
                for (int i = 0; i < 9; i++)
                {
                    if (tempBoard[i] == CellState.Empty)
                    {
                        tempBoard[i] = CellState.O;
                        int score = Minimax(tempBoard, depth + 1, false);
                        tempBoard[i] = CellState.Empty;
                        bestScore = Mathf.Max(score, bestScore);
                    }
                }
                return bestScore;
            }
            else
            {
                int bestScore = int.MaxValue;
                for (int i = 0; i < 9; i++)
                {
                    if (tempBoard[i] == CellState.Empty)
                    {
                        tempBoard[i] = CellState.X;
                        int score = Minimax(tempBoard, depth + 1, true);
                        tempBoard[i] = CellState.Empty;
                        bestScore = Mathf.Min(score, bestScore);
                    }
                }
                return bestScore;
            }
        }

        private bool CheckWin(CellState[] tempBoard, CellState player)
        {
            int[][] winConditions = new int[][]
            {
                new int[] {0, 1, 2},
                new int[] {3, 4, 5},
                new int[] {6, 7, 8},
                new int[] {0, 3, 6},
                new int[] {1, 4, 7},
                new int[] {2, 5, 8},
                new int[] {0, 4, 8},
                new int[] {2, 4, 6}
            };

            foreach (var condition in winConditions)
            {
                if (tempBoard[condition[0]] == player &&
                    tempBoard[condition[1]] == player &&
                    tempBoard[condition[2]] == player)
                    return true;
            }
            return false;
        }

        private bool IsBoardFull(CellState[] tempBoard)
        {
            for (int i = 0; i < 9; i++)
            {
                if (tempBoard[i] == CellState.Empty)
                    return false;
            }
            return true;
        }
    }
} 