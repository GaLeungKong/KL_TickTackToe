namespace TicTacToe
{
    public class GameState
    {
        public enum State { 
            Playing, 
            PlayerWon, 
            AIWon, 
            Draw 
        }    // game states
        
        private State currentState;
        private bool  isPlayerTurn;    // 是否玩家回合
        
        public event System.Action<State> OnStateChanged;
        public event System.Action<bool> OnTurnChanged;

        public State CurrentState => currentState;
        public bool IsPlayerTurn => isPlayerTurn;

        public GameState()
        {
            // 初始化
            currentState = State.Playing;
            isPlayerTurn = true;    // player first
        }

        public void SetState(State newState)
        {
            if (currentState != newState)
            {
                currentState= newState;
                OnStateChanged?.Invoke(newState);
            }
        }

        public void SwitchTurn()
        {
            isPlayerTurn = !isPlayerTurn;
            OnTurnChanged?.Invoke(isPlayerTurn);
        }


        public void Reset()
        {
            currentState = State.Playing;
            isPlayerTurn = true;
            OnStateChanged?.Invoke(currentState);
            OnTurnChanged?.Invoke(isPlayerTurn);
        }
    }
} 