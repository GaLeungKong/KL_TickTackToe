namespace TicTacToe
{
    public class Board
    {
        private CellState[] cells;
        public event System.Action<int, CellState> OnCellChanged;

        public Board()
        {
            cells = new CellState[9];
        }

        public CellState GetCell(int index) => cells[index];

        public bool SetCell(int index, CellState state)
        {
            if (index < 0 || index >= 9 || cells[index] != CellState.Empty)
                return false;

            cells[index] = state;
            OnCellChanged?.Invoke(index, state);
            return true;
        }

        public void Reset()
        {
            for (int i = 0; i < 9; i++)
            {
                cells[i] = CellState.Empty;
                OnCellChanged?.Invoke(i, CellState.Empty);
            }
        }

        public bool IsFull()
        {
            for (int i = 0; i < 9; i++)
            {
                if (cells[i] == CellState.Empty)
                    return false;
            }
            return true;
        }
    }
} 