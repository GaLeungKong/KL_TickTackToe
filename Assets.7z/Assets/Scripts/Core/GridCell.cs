using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace TicTacToe
{
    public class GridCell : MonoBehaviour
    {
        [SerializeField] private Button button;
        [SerializeField] private TMP_Text text;

        public Button Button => button;

        private void Start()
        {
            text.text = GameText.EMPTY_CELL;
            text.fontSize = GameText.CELL_FONT_SIZE;
            text.alignment = TextAlignmentOptions.Center;
        }

        public void SetState(CellState state)
        {
            text.text = state switch
            {
                CellState.X => GameText.PLAYER_SYMBOL,
                CellState.O => GameText.AI_SYMBOL,
                _ => GameText.EMPTY_CELL
            };
            button.interactable = (state == CellState.Empty);
        }
    }
} 