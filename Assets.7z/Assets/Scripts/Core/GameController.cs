using UnityEngine;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class GameController : MonoBehaviour
    {
        [SerializeField] private AIDifficulty initialDifficulty = AIDifficulty.Medium;
        
        private Board board;
        private GameState gameState;
        private AIPlayer aiPlayer;
        private GameUI gameUI;

        private void Start()
        {
            Initialize();
        }

        private void Initialize()
        {
            board = new Board();
            gameState = new GameState();
            aiPlayer = new AIPlayer(board, initialDifficulty);
            gameUI = GetComponent<GameUI>();

            // 订阅事件
            board.OnCellChanged += OnBoardCellChanged;
            gameState.OnStateChanged += OnGameStateChanged;
            gameState.OnTurnChanged += OnTurnChanged;

            RestartGame();
        }

        public async void OnPlayerMove(int index)
        {
            if (!gameState.IsPlayerTurn || gameState.CurrentState != GameState.State.Playing)
                return;

            if (board.SetCell(index, CellState.X))
            {
                gameState.SwitchTurn();  // 先切换回合
                if (CheckGameEnd())      // 再检查游戏结束
                    return;
                
                await HandleAITurn();
            }
        }

        private async Task HandleAITurn()
        {
            gameUI.UpdateStatus(GameText.AI_THINKING);
            await Task.Delay(500);

            int aiMove = await aiPlayer.GetNextMoveAsync();
            
            if (aiMove >= 0 && aiMove < 9 && board.GetCell(aiMove) == CellState.Empty)
            {
                board.SetCell(aiMove, CellState.O);
                
                if (!CheckGameEnd())     // 检查游戏结束
                {
                    gameState.SwitchTurn();  // 如果游戏没结束才切换回合
                }
            }
            else
            {
                gameState.SwitchTurn();
            }
        }

        public void RestartGame()
        {
            board.Reset();
            gameState.Reset();
            gameUI.UpdateStatus(GameText.YOUR_TURN);
        }

        private bool CheckGameEnd()
        {
            // 检查玩家胜利
            if (CheckWin(CellState.X))
            {
                gameState.SetState(GameState.State.PlayerWon);
                return true;
                
            }
            
            // 检查AI胜利
            if (CheckWin(CellState.O))
            {
                gameState.SetState(GameState.State.AIWon);
                return true;
            }
            
            // 检查平局
            if (board.IsFull())
            {
                gameState.SetState(GameState.State.Draw);
                return true;
            }
            
            return false;
        }

        private bool CheckWin(CellState player)
        {
            int[][] winConditions = new int[][]
            {
                new int[] {0, 1, 2},
                new int[] {3, 4, 5},
                new int[] {6, 7, 8},
                new int[] {0, 3, 6},
                new int[] {1, 4, 7},
                new int[] {2, 5, 8},
                new int[] {0, 4, 8},
                new int[] {2, 4, 6}
            };

            foreach (var condition in winConditions)
            {
                if (board.GetCell(condition[0]) == player &&
                    board.GetCell(condition[1]) == player &&
                    board.GetCell(condition[2]) == player)
                    return true;
            }
            return false;
        }

        private void OnBoardCellChanged(int index, CellState state)
        {
            gameUI.UpdateCell(index, state);
        }

        private void OnGameStateChanged(GameState.State state)
        {
            switch (state)
            {
                case GameState.State.PlayerWon:
                    gameUI.UpdateStatus(GameText.YOU_WIN);
                    break;
                case GameState.State.AIWon:
                    gameUI.UpdateStatus(GameText.AI_WIN);
                    break;
                case GameState.State.Draw:
                    gameUI.UpdateStatus(GameText.DRAW);
                    break;
            }
        }

        private void OnTurnChanged(bool isPlayerTurn)
        {
            if (isPlayerTurn)
                gameUI.UpdateStatus(GameText.YOUR_TURN);
        }

        public void SetAIDifficulty(AIDifficulty difficulty)
        {
            aiPlayer.SetDifficulty(difficulty);
        }
    }
} 