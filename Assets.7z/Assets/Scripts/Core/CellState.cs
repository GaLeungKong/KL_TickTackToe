namespace TicTacToe
{
    public enum CellState
    {
        Empty,     // 空
        X,         // player
        O         // AI
    }  // end of cellstate
} 